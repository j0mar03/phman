<?php

class Model1 extends CI_Model
{
   public function __construct()
   {
      parent::__construct();
   }

   public function getList()
   {
     echo 1213133;
   }
}