<div class="dashboard-na">
   <h2>Sorry, but your user account is not allowed to access dashboard information.</h2>
</div>