<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

define("MODULES_PATH",APPPATH . 'modules/');