<div id="side" class="nm np">
	<div class="side_box">
		<ul class="smb fnt nl np nm">
			<li class="current"><a href="#">Manage Expense</a></li>
			<li>
				<dl class="smb_sub nl np nm">
					<dt><a href="#">Manage Settings</a></dt>
					<dd><a href="#">Stock Information</a></dd>
					<dd><a href="#">Product Information</a></dd>
					<dd><a href="#">Category 2C</a></dd>
					<dd><a href="#">Category 2D</a></dd>
				</dl>
			</li>
			<li><a href="#">HR Management</a></li>
			<li><a href="#">Seat Arrangement</a></li>
			<li><a href="#">Employees</a></li>
			<li class="nm"><a href="#">Computer and Hardwares</a></li>
		</ul>
	</div>
</div>