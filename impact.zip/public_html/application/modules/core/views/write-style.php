<?php if($awrite_style){ ?>
<style type="text/css">
<?php
foreach($awrite_style as $rows){
   echo $rows . PHP_EOL;
}
?>
</style>
<?php }?>
