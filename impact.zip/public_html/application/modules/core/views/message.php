<div class="core-message-server-<?php echo $unique;?>">
   <div class="<?php echo $class_name;?>">
      <span class="core-message-server-text"><?php echo $message ;?></span>
      <a class="core-message-close core-message-server-close-button" href="javascript:site.message('',$('.core-message-server-<?php echo $unique;?>'),'hide')" alt="<?php echo $unique;?>">x</a>
   </div>
</div>